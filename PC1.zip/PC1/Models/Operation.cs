namespace PC1.Models
{
    public class Operation
    {
        public int Id { get; set; }
        public String? Name { get; set; }
        public String? Email { get; set; }
        public DateTime DateOfOperation { get; set; }
        public List<Instrument>? Instruments { get; set; }
        public decimal Amount { get; set; }
        public decimal Commission { get; set; }
        public decimal IGV { get; set; }
        public decimal TotalToPay { get; set; }
    }
}
